package com.ubs.cloudservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CloudserviceApplication {

	public static void main(String[] args) {
		SpringApplication.run(CloudserviceApplication.class, args);
	}

}
